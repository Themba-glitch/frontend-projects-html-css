// translations.js - Multi-language support for Safe Haven website
const translations = {
  en: {
    // Header
    home: "Home",
    about: "About Us",
    services: "Services",
    workWithUs: "Work With Us",
    contact: "Contact",
    
    // Home Page
    heroTitle: "Together We Can End GBV",
    heroSubtitle: "Providing safety, hope, and empowerment for women and girls in South Africa.",
    welcomeTitle: "Welcome to Safe Haven",
    welcomeText: "Safe Haven is a non-profit organization dedicated to protecting and supporting women and girls who have faced gender-based violence. Our mission is to create safe spaces, restore dignity, and empower survivors to rebuild their lives.",
    
    // About Page
    aboutTitle: "About Us",
    aboutText1: "Safe Haven is a non-profit organization and a women's shelter dedicated to serving women and girls who have experienced sexual abuse and domestic violence or any other form of Gender-Based Violence.",
    aboutText2: "Our mission is to offer a safe, compassionate, and empowering space for healing, support, and restoration. Established in 2024, Safe Haven has successfully restored and empowered many women who have fallen victim to the current epidemic that has crowded our country in recent years.",
    aboutText3: "The NGO aims to expand its reach to greater heights. The aim is to grow and branch into every province, helping all women in need.",
    
    // Services Page
    servicesTitle: "Our Services",
    shelter: "Shelter & Safety",
    shelterDesc: "Providing safe housing for women and children in need.",
    counseling: "Counseling",
    counselingDesc: "Emotional and psychological support from trained professionals.",
    education: "Education & Skills",
    educationDesc: "Workshops, training, and resources to empower independence.",
    legal: "Legal Support",
    legalDesc: "Guidance in accessing justice and protecting victims' rights.",
    outreach: "Community Outreach",
    outreachDesc: "Programs tailored to raise awareness and promote prevention.",
    
    // Work With Us Page
    joinTitle: "Join Our Mission",
    joinIntro: "At Safe Haven, we believe in the power of unity to bring change. Whether you want to volunteer, donate, or partner with us, your contribution makes a difference.",
    volunteer: "Volunteer",
    volunteerDesc: "Offer your time and skills to support women and girls in need.",
    donate: "Donate",
    donateDesc: "Help us expand our reach and provide life-saving resources.",
    partnerships: "Partnerships",
    partnershipsDesc: "Collaborate with us to fight gender-based violence nationwide.",
    advocate: "Advocate",
    advocateDesc: "Be a voice for survivors and spread awareness in your community.",
    
    // Volunteer Form
    volunteerFormTitle: "Volunteer With Us",
    volunteerFormDesc: "Share your time and talents to make a real difference in survivors' lives.",
    fullName: "Full Name",
    email: "Email Address",
    phone: "Phone Number",
    preferredDate: "Preferred Start Date",
    preferredTime: "Preferred Time",
    duration: "Duration of Commitment",
    skills: "Skills & Experience",
    message: "Message",
    required: "*",
    submit: "Submit Volunteer Application",
    successVolunteer: "Thank you! Your volunteer application has been submitted successfully.",
    
    // Donation Form
    donationFormTitle: "Support Through Donations",
    donationFormDesc: "Your generosity provides essential resources to survivors in need.",
    organization: "Full Name / Organization",
    iAm: "I am a",
    individual: "Individual",
    business: "Business/Corporate",
    foundation: "Foundation/Trust",
    whatToDonate: "What would you like to donate?",
    money: "Money",
    clothes: "Clothes",
    food: "Food Hampers",
    sanitary: "Sanitary Products",
    other: "Other Items",
    amount: "Estimated Amount / Quantity (if applicable)",
    frequency: "Donation Frequency",
    oneTime: "One-time",
    monthly: "Monthly",
    quarterly: "Quarterly",
    annually: "Annually",
    submitDonation: "Submit Donation Inquiry",
    successDonation: "Thank you! Your donation inquiry has been submitted successfully.",
    
    // Contact Page
    contactTitle: "Contact Us",
    contactEmail: "Email",
    contactPhone: "Phone",
    emergencyHotline: "24/7 Emergency Hotline",
    address: "Address",
    tagline: "We're here for you, 24/7. You are not alone.",
    followUs: "Follow Us",
    
    // Footer
    footerText: "Empowering Women & Ending Gender-Based Violence",
    
    // Time Options
    morning: "Morning (8AM - 12PM)",
    afternoon: "Afternoon (12PM - 4PM)",
    evening: "Evening (4PM - 8PM)",
    flexible: "Flexible",
    
    // Duration Options
    oneTimeEvent: "One-time event",
    weekly: "Weekly",
    threeMonths: "3 months",
    sixMonths: "6 months",
    oneYear: "1 year or more",
    
    // Validation
    selectType: "Select type",
    selectTime: "Select a time",
    selectDuration: "Select duration",
    selectOneType: "Please select at least one donation type."
  },
  
  af: {
    // Header
    home: "Tuis",
    about: "Oor Ons",
    services: "Dienste",
    workWithUs: "Werk Saam Met Ons",
    contact: "Kontak",
    
    // Home Page
    heroTitle: "Saam Kan Ons GBV Beëindig",
    heroSubtitle: "Verskaffing van veiligheid, hoop en bemagtiging vir vroue en meisies in Suid-Afrika.",
    welcomeTitle: "Welkom by Safe Haven",
    welcomeText: "Safe Haven is 'n nie-winsgewende organisasie toegewy aan die beskerming en ondersteuning van vroue en meisies wat geslagsgebaseerde geweld ervaar het. Ons missie is om veilige ruimtes te skep, waardigheid te herstel en oorlewendes te bemagtig om hul lewens te herbou.",
    
    // About Page
    aboutTitle: "Oor Ons",
    aboutText1: "Safe Haven is 'n nie-winsgewende organisasie en 'n vroueskuiling toegewy aan die diens van vroue en meisies wat seksuele misbruik en huishoudelike geweld of enige ander vorm van Geslagsgebaseerde Geweld ervaar het.",
    aboutText2: "Ons missie is om 'n veilige, deernisvolle en bemagtigende ruimte vir genesing, ondersteuning en herstel te bied. Gestig in 2024, het Safe Haven baie vroue wat slagoffer geval het van die huidige epidemie wat ons land die afgelope jare oorval het, suksesvol herstel en bemagtig.",
    aboutText3: "Die NGO beoog om sy bereik na groter hoogtes uit te brei. Die doel is om te groei en in elke provinsie te vestig, en alle vroue in nood te help.",
    
    // Services Page
    servicesTitle: "Ons Dienste",
    shelter: "Skuiling & Veiligheid",
    shelterDesc: "Verskaffing van veilige behuising vir vroue en kinders in nood.",
    counseling: "Berading",
    counselingDesc: "Emosionele en sielkundige ondersteuning van opgeleide professionele persone.",
    education: "Opvoeding & Vaardighede",
    educationDesc: "Werkswinkels, opleiding en hulpbronne om onafhanklikheid te bemagtig.",
    legal: "Regsondersteuning",
    legalDesc: "Leiding in die toegang tot geregtigheid en die beskerming van slagoffers se regte.",
    outreach: "Gemeenskapsuitreik",
    outreachDesc: "Programme wat aangepas is om bewustheid te verhoog en voorkoming te bevorder.",
    
    // Work With Us Page
    joinTitle: "Sluit Aan By Ons Missie",
    joinIntro: "By Safe Haven glo ons in die krag van eenheid om verandering te bring. Of jy wil vrywillig werk, skenk, of met ons vennoot, jou bydrae maak 'n verskil.",
    volunteer: "Vrywilliger",
    volunteerDesc: "Bied jou tyd en vaardighede aan om vroue en meisies in nood te ondersteun.",
    donate: "Skenk",
    donateDesc: "Help ons om ons bereik uit te brei en lewensreddende hulpbronne te verskaf.",
    partnerships: "Vennootskappe",
    partnershipsDesc: "Werk saam met ons om geslagsgebaseerde geweld landwyd te beveg.",
    advocate: "Voorstaan",
    advocateDesc: "Wees 'n stem vir oorlewendes en versprei bewustheid in jou gemeenskap.",
    
    // Volunteer Form
    volunteerFormTitle: "Vrywillig Saam Met Ons",
    volunteerFormDesc: "Deel jou tyd en talente om 'n werklike verskil in oorlewendes se lewens te maak.",
    fullName: "Volle Naam",
    email: "E-posadres",
    phone: "Telefoonnommer",
    preferredDate: "Voorkeur Begindatum",
    preferredTime: "Voorkeur Tyd",
    duration: "Duur van Verbintenis",
    skills: "Vaardighede & Ervaring",
    message: "Boodskap",
    required: "*",
    submit: "Dien Vrywilligersaansoek In",
    successVolunteer: "Dankie! Jou vrywilligersaansoek is suksesvol ingedien.",
    
    // Donation Form
    donationFormTitle: "Ondersteun Deur Skenkings",
    donationFormDesc: "Jou vrygewigheid verskaf noodsaaklike hulpbronne aan oorlewendes in nood.",
    organization: "Volle Naam / Organisasie",
    iAm: "Ek is 'n",
    individual: "Individu",
    business: "Besigheid/Korporatief",
    foundation: "Stigting/Trust",
    whatToDonate: "Wat wil jy skenk?",
    money: "Geld",
    clothes: "Klere",
    food: "Voedselpakkette",
    sanitary: "Sanitêre Produkte",
    other: "Ander Items",
    amount: "Beraamde Bedrag / Hoeveelheid (indien van toepassing)",
    frequency: "Skenkingsfrekwensie",
    oneTime: "Eenmalig",
    monthly: "Maandeliks",
    quarterly: "Kwartaalliks",
    annually: "Jaarliks",
    submitDonation: "Dien Skenkingnavraag In",
    successDonation: "Dankie! Jou skenkingnavraag is suksesvol ingedien.",
    
    // Contact Page
    contactTitle: "Kontak Ons",
    contactEmail: "E-pos",
    contactPhone: "Telefoon",
    emergencyHotline: "24/7 Noodhulplyn",
    address: "Adres",
    tagline: "Ons is hier vir jou, 24/7. Jy is nie alleen nie.",
    followUs: "Volg Ons",
    
    // Footer
    footerText: "Bemagtiging van Vroue & Beëindiging van Geslagsgebaseerde Geweld",
    
    // Time Options
    morning: "Oggend (8VM - 12NM)",
    afternoon: "Middag (12NM - 4NM)",
    evening: "Aand (4NM - 8NM)",
    flexible: "Buigsaam",
    
    // Duration Options
    oneTimeEvent: "Eenmalige gebeurtenis",
    weekly: "Weekliks",
    threeMonths: "3 maande",
    sixMonths: "6 maande",
    oneYear: "1 jaar of meer",
    
    // Validation
    selectType: "Kies tipe",
    selectTime: "Kies 'n tyd",
    selectDuration: "Kies duur",
    selectOneType: "Kies asseblief ten minste een skenkingstipe."
  },
  
  zu: {
    // Header
    home: "Ikhaya",
    about: "Mayelana Nathi",
    services: "Izinsizakalo",
    workWithUs: "Sebenza Nathi",
    contact: "Xhumana",
    
    // Home Page
    heroTitle: "Ndawonye Singaqeda I-GBV",
    heroSubtitle: "Sinikeza ukuphepha, ithemba, nokuqinisa abesifazane namantombazane eNingizimu Afrika.",
    welcomeTitle: "Siyakwamukela e-Safe Haven",
    welcomeText: "I-Safe Haven iyinhlangano engenzi nzuzo ezinikele ekuvikeleni nasekusekeleni abesifazane namantombazane ababebhekene nodlame olusekelwe ebulilini. Umsebenzi wethu ukudala izikhala eziphephile, ukubuyisela isithunzi, nokuqinisa abasindile ukuba bakhe kabusha izimpilo zabo.",
    
    // About Page
    aboutTitle: "Mayelana Nathi",
    aboutText1: "I-Safe Haven iyinhlangano engenzi nzuzo nendawo yokuphephela yabesifazane ezinikele ekusizeni abesifazane namantombazane abahlukumeze ngokocansi nodlame basekhaya noma noma yiluphi olunye uhlobo loDlame Olusekelwe Ebulilini.",
    aboutText2: "Umsebenzi wethu ukunikeza indawo ephephile, enozwela, neqinisayo yokuphulukisa, ukweseka, nokubuyisa. Yasungulwa ngo-2024, i-Safe Haven isibuyisile futhi yaqinisa abesifazane abaningi ababeyizisulu zesifo samanje esimemeze izwe lethu eminyakeni yakamuva.",
    aboutText3: "I-NGO ihlose ukwandisa ukufinyelela kwayo ezingqongqoshe ezinkulu. Inhloso ukukhula nokugxila kuzo zonke izifundazwe, ukusiza bonke abesifazane abadinga usizo.",
    
    // Services Page
    servicesTitle: "Izinsizakalo Zethu",
    shelter: "Indawo Yokuphephela & Ukuphepha",
    shelterDesc: "Sinikeza izindlu eziphephile zabesifazane nezingane ezidinga usizo.",
    counseling: "Ukeluleko",
    counselingDesc: "Ukwesekwa ngokwemizwa nangokwengqondo kusuka kochwepheshe abaqeqeshiwe.",
    education: "Imfundo & Amakhono",
    educationDesc: "Izingqungquthela, ukuqeqeshwa, nezinsiza zokuqinisa ukuzimela.",
    legal: "Ukwesekwa Ngokwezomthetho",
    legalDesc: "Ukuqondisa ekufinyeleleni ubulungiswa nasekuvikeleni amalungelo ezisulu.",
    outreach: "Ukufinyelela Emphakathini",
    outreachDesc: "Izinhlelo ezenzelwe ukukhuphula ukuqwashisa nokugqugquzela ukuvimbela.",
    
    // Work With Us Page
    joinTitle: "Joyina Umsebenzi Wethu",
    joinIntro: "E-Safe Haven, sikholelwa emandleni obunye ukuletha ushintsho. Noma ufuna ukusebenza ngokovolontiya, ukusiza, noma ukubambisana nathi, umnikelo wakho wenza umehluko.",
    volunteer: "Ukusebenza Ngokovolontiya",
    volunteerDesc: "Nikela ngesikhathi namakhono akho ukusekela abesifazane namantombazane abadinga usizo.",
    donate: "Nikela",
    donateDesc: "Sisize ukwandisa ukufinyelela kwethu futhi sinikeze izinsiza zokusindisa impilo.",
    partnerships: "Ubambiswano",
    partnershipsDesc: "Bambisana nathi ukulwa nodlame olusekelwe ebulilini ezweni lonke.",
    advocate: "Mela",
    advocateDesc: "Yiba izwi labasindile futhi usabalalise ukuqwashisa emphakathini wakho.",
    
    // Volunteer Form
    volunteerFormTitle: "Sebenza Ngokovolontiya Nathi",
    volunteerFormDesc: "Yabelana ngesikhathi nemitho yakho ukwenza umehluko weqiniso ezimpilweni zabasindile.",
    fullName: "Igama Elizele",
    email: "Ikheli Le-imeyili",
    phone: "Inombolo Yocingo",
    preferredDate: "Usuku Lokuqala Oluncamelayo",
    preferredTime: "Isikhathi Esincamelayo",
    duration: "Ubude Bokuzibophezela",
    skills: "Amakhono & Ulwazi",
    message: "Umlayezo",
    required: "*",
    submit: "Thumela Isicelo Sokovolontiya",
    successVolunteer: "Siyabonga! Isicelo sakho sokovolontiya sithunyelwe ngempumelelo.",
    
    // Donation Form
    donationFormTitle: "Sekela Ngeminikelo",
    donationFormDesc: "Ukuphana kwakho kunikeza izinsiza ezidingekayo kubasindile abadinga usizo.",
    organization: "Igama Elizele / Inhlangano",
    iAm: "Ngingu",
    individual: "Umuntu",
    business: "Ibhizinisi/Inkampani",
    foundation: "Isisekelo/Ithrasti",
    whatToDonate: "Yini ofuna ukuyinikela?",
    money: "Imali",
    clothes: "Izingubo",
    food: "Amaphasela Okudla",
    sanitary: "Imikhiqizo Yokuhlambulula",
    other: "Ezinye Izinto",
    amount: "Inani Elilinganiselwayo / Ubuningi (uma kufanelekile)",
    frequency: "Imvamisa Yokunikela",
    oneTime: "Kanye",
    monthly: "Njalo ngenyanga",
    quarterly: "Ngesikota ngasinye",
    annually: "Minyaka yonke",
    submitDonation: "Thumela Umbuzo Wokunikela",
    successDonation: "Siyabonga! Umbuzo wakho wokunikela uthunyelwe ngempumelelo.",
    
    // Contact Page
    contactTitle: "Xhumana Nathi",
    contactEmail: "I-imeyili",
    contactPhone: "Ucingo",
    emergencyHotline: "Ulayini Wosizo Lwesiphuthumakuno 24/7",
    address: "Ikheli",
    tagline: "Silapha ngawe, 24/7. Awuwedwa.",
    followUs: "Silandele",
    
    // Footer
    footerText: "Ukuqinisa Abesifazane & Ukuqeda Udlame Olusekelwe Ebulilini",
    
    // Time Options
    morning: "Ekuseni (8AM - 12PM)",
    afternoon: "Emini (12PM - 4PM)",
    evening: "Kusihlwa (4PM - 8PM)",
    flexible: "Okunokuguquguquka",
    
    // Duration Options
    oneTimeEvent: "Umcimbi wesikhathi esisodwa",
    weekly: "Masonto onke",
    threeMonths: "Izinyanga ezi-3",
    sixMonths: "Izinyanga ezi-6",
    oneYear: "Unyaka o-1 noma ngaphezulu",
    
    // Validation
    selectType: "Khetha uhlobo",
    selectTime: "Khetha isikhathi",
    selectDuration: "Khetha ubude",
    selectOneType: "Sicela ukhethe okungenani uhlobo olulodwa lokunikela."
  }
};